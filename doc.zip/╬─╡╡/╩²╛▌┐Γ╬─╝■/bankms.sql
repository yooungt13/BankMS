/*
SQLyog Ultimate v8.7 
MySQL - 5.5.0-m2-community : Database - bankms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bankms` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bankms`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `id` int(20) NOT NULL COMMENT '账户ID',
  `type` varchar(5) NOT NULL COMMENT '账户类型 0活期/1死期',
  `balance` float NOT NULL COMMENT '当前余额',
  `sts` tinyint(1) NOT NULL COMMENT '销户状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`id`,`type`,`balance`,`sts`) values (1,'00',11067.5,1),(2,'01',1399.99,1),(3,'10',-4498,1),(4,'11',200,1),(5,'00',100.2,0),(6,'11',300.2,1),(7,'11',617.7,1),(8,'10',110.45,1),(9,'00',175.5,1),(10,'00',100,1),(11,'01',100,1),(12,'20',10310,1),(13,'11',5050,0),(14,'10',5000,1);

/*Table structure for table `log` */

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `op_type` int(10) NOT NULL COMMENT '0开户/1存款/2取款/3查询/4转账/5修改密码/6销户/7创建企业用户',
  `op_time` datetime NOT NULL COMMENT '日志时间',
  `content` varchar(100) NOT NULL COMMENT '日志内容',
  `op_id` int(20) NOT NULL COMMENT '操作员id',
  `ac_id` int(20) NOT NULL COMMENT '账户id',
  `user_id` int(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

/*Data for the table `log` */

insert  into `log`(`id`,`op_type`,`op_time`,`content`,`op_id`,`ac_id`,`user_id`) values (1,0,'1999-12-25 14:25:00','Open Account',1,1,1),(2,1,'2005-03-08 09:12:40','Save $100',2,1,1),(3,2,'2005-03-09 10:10:00','Withdraw $55',1,1,1),(4,0,'2000-01-02 01:22:32','Open Account',1,2,2),(5,4,'2013-11-22 21:25:56','Transfer out $100.0,<br> total 567.55',1,1,1),(6,4,'2013-11-22 21:25:56','Transfer in $100.0,<br> total 1399.99',1,2,2),(7,0,'2013-11-22 21:50:24','Open Account',1,11,11),(8,1,'2013-11-22 21:59:42','Save $100.0,<br>total $667.55',1,1,1),(9,1,'2013-11-22 21:59:54','Save $150.0,<br>total $817.55',1,1,1),(10,1,'2013-11-22 22:02:44','Save $200.0, total $1017.55',1,1,1),(11,1,'2013-11-22 22:03:00','Save $200.0, total $1217.55',1,1,1),(12,1,'2013-11-22 22:04:13','Save $100.0, <br>total $200.0',3,4,4),(13,2,'2013-11-22 22:04:24','Withdraw $50.0, <br>total $11002.0',3,3,3),(14,2,'2013-11-22 22:04:32','Withdraw $500.0, <br>total $10502.0',3,3,3),(15,2,'2013-11-22 22:04:50','Withdraw $50000.0, <br>total $false',3,3,3),(16,2,'2013-11-22 22:04:53','Withdraw $5000.0, <br>total $5502.0',3,3,3),(17,6,'2013-11-22 22:15:00','Close Account,<br>and Withdraw whole money',4,5,5),(18,3,'2013-11-25 13:36:04','Check Account',1,1,1),(19,3,'2013-11-25 13:36:08','Check Account',1,1,1),(20,3,'2013-11-25 13:36:09','Check Account',1,1,1),(21,0,'2013-11-25 15:18:23','Open Account',1,12,12),(22,3,'2013-11-25 15:19:03','Check Account',1,12,12),(23,3,'2013-11-25 15:19:06','Check Account',1,12,12),(24,1,'2013-11-28 16:56:48','Save $100.0, <br>total $1667.55',1,1,1),(25,1,'2013-11-28 16:56:50','Save $100.0, <br>total $1767.55',1,1,1),(26,1,'2013-11-28 16:57:09','Save $100.0, <br>total $200.2',1,6,6),(27,4,'2013-12-06 21:48:06','Transfer out $500.0, <br>total 1267.55',1,1,1),(28,4,'2013-12-06 21:48:06','Transfer in $500.0, <br>total 740.7',1,7,1),(29,4,'2013-12-06 21:49:13','Transfer out $100.0, <br>total 1167.55',1,1,1),(30,4,'2013-12-06 21:49:13','Transfer in $100.0, <br>total 840.7',1,7,1),(31,4,'2013-12-06 21:49:36','Transfer out $100.0, <br>total 740.7',1,7,1),(32,4,'2013-12-06 21:49:36','Transfer in $100.0, <br>total 1267.55',1,1,1),(33,2,'2013-12-06 22:16:23','Withdraw $200.0, <br>total $1067.55',1,1,1),(34,2,'2013-12-06 22:16:45','Withdraw $10000.0, <br>total $-4498.0',1,3,3),(35,2,'2013-12-06 22:18:27','Withdraw $340.0, <br>total $10010.0',1,12,12),(36,5,'2013-12-06 22:19:30','Change Password',1,1,1),(37,1,'2013-12-10 22:23:33','Save $100.0, <br>total $300.2',4,6,6),(38,2,'2013-12-10 22:23:56','Withdraw $123.0, <br>total $617.7',4,7,1),(39,0,'2013-12-11 15:39:04','Open Account',3,13,13),(40,1,'2013-12-11 15:39:34','Save $100.0, <br>total $10100.0',3,13,13),(41,2,'2013-12-11 15:39:58','Withdraw $50.0, <br>total $10050.0',3,13,13),(42,4,'2013-12-11 15:40:40','Transfer out $5000.0, <br>total 5050.0',3,13,13),(43,4,'2013-12-11 15:40:40','Transfer in $5000.0, <br>total 6067.55',3,1,1),(44,3,'2013-12-11 15:41:05','Check Account',3,13,13),(45,5,'2013-12-11 15:42:51','Change Password',3,13,13),(46,6,'2013-12-11 15:43:25','Close Account,<br>and Withdraw whole money',3,13,13),(47,1,'2013-12-11 16:35:35','Save $100.0, <br>total $10110.0',2,12,12),(48,7,'2013-12-11 16:56:12','Add Super 1 to Account 12',4,12,12),(49,1,'2013-12-11 17:00:53','Save $100.0, <br>total $10210.0',4,12,1),(50,1,'2013-12-11 17:00:56','Save $100.0, <br>total $10310.0',4,12,12),(51,0,'2013-12-12 14:04:21','Open Account',1,14,14),(52,4,'2013-12-12 14:05:21','Transfer out $5000.0, <br>total 5000.0',1,14,14),(53,4,'2013-12-12 14:05:21','Transfer in $5000.0, <br>total 11067.55',1,1,1);

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(12) NOT NULL AUTO_INCREMENT COMMENT '员工id',
  `password` varchar(12) NOT NULL COMMENT '登录密码',
  `type` int(10) unsigned NOT NULL COMMENT '员工类型 0前台/1经理/2主管/3系统管理员',
  `name` varchar(20) NOT NULL COMMENT '员工姓名',
  `department` varchar(20) NOT NULL,
  `bank` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `login` */

insert  into `login`(`id`,`password`,`type`,`name`,`department`,`bank`) values (1,'123',0,'Teller','1','1'),(2,'123',1,'Dept Manager','1','1'),(3,'123',2,'Director','3','1'),(4,'123',3,'Administrator','4','1'),(5,'123',0,'Teller B','2','1'),(6,'123',0,'Teller C','2','1'),(7,'123',1,'Manager B','2','1'),(8,'123',2,'Director B','3','1');

/*Table structure for table `relationship` */

DROP TABLE IF EXISTS `relationship`;

CREATE TABLE `relationship` (
  `ac_id` int(20) NOT NULL COMMENT '账户id',
  `user_id` int(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`ac_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `relationship` */

insert  into `relationship`(`ac_id`,`user_id`) values (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,1),(8,8),(9,9),(10,10),(11,11),(12,1),(12,12),(13,13),(14,14);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `identifier` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`username`,`password`,`identifier`) values (1,'Titan','123','140030'),(2,'George','1234','140032'),(3,'Tony','1234','140033'),(4,'Bosh','123','140034'),(5,'Manning','123','140035'),(6,'Penny','123','140036'),(7,'Jenna','123','140037'),(8,'Alpha','123','140038'),(9,'Webb','123','140032'),(10,'Crush','123','140040'),(11,'Sicily','123','140041'),(12,'Susan','1234','140055'),(13,'Rick','1234','140040'),(14,'Tracy','123','140031');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
